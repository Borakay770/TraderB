# TraderB
We are looking all ways for make the best and the worst of them truly 
